; irred.s: IBM PC assembler routines for irred version 3.10 and above
;
; Copyright (C) 2001 Richard P. Brent.
;
; These routines come with absolutely no warranty.
; For conditions of use see the GNU General Public License
; and the comments in the calling program irred.c (version 3.10 or above).
;
; Contents:
;
;        cpuinfo	checks cpu information
;        checkmmx	checks if MMX instructions usable
;	 reducer	alternative to C reducer
;	 reducemr	similar to C reducer  (using MMX instructions)
;	 reducemx	similar to reducemr if first arg not aligned
;	 interlvf	alternative to C interlvf (using MMX instructions)
;	 interlvr	alternative to C interlvr (using MMX instructions)
;
; Richard Brent (rpb@comlab.ox.ac.uk), last revised 20010607
;
; Assemble with
;
;     nasm -f elf -o irred.o irred.s
;
;######################################## cpuinfo ############################
;
; void cpuinfo(flag, results)
; int flag;
; int results[4];
;
; Returns the cpu information given by cpuid instruction in
; (eax, ebx, edx, ecx) -> (results[0], .. , results[3])
; with input eax = flag.
;
	section .text
	align 16
	global cpuinfo

cpuinfo:
	pusha
	mov  eax, [esp+36]		; flag -> eax
	cpuid				; see Intel documentation for effect
	mov edi, [esp+40]
	mov [edi], eax			; return results (eax, ebx, edx, ecx)
	mov [edi+4], ebx		; in second argument array
	mov [edi+8], edx
	mov [edi+12], ecx
	popa
	ret

;######################################## checkmmx ###########################
;
; int checkmmx();
;
; Returns 1 if MMX instructions are usable, 0 if not
;
	section .text
	align 16
	global checkmmx

checkmmx:
	pusha				; save registers
	mov  eax, 1
	cpuid
	shr edx, byte 23		; check bit 23
	and edx, byte 1			; nonzero if MMX OK
	mov [esp+28], edx		; overwrite stored eax
	popa				; restore registers and return eax
	ret

;######################################## reducer #############################
;
; Version 2.40 of reducer
;
; typedef unsigned long ULONG;
; void reducer(ULONG *a, ULONG *b, int kt, int shift, ULONG *prev)
;
; Equivalent to C reducer (with loop unrolled twice)
; except that the assembler code works if shift is zero, unlike the C code.
;
; This code seems to be faster than the MMX code reducemr/reducemx
; if data is already in the L1 cache (i.e. very small r) or if there
; are data alignment problems.
; This is partly because the shrd instruction is very convenient
; here and has no MMX equivalent.
;
; All the "reduce" routines are limited by memory bandwidth if data is
; not in the L2 cache.  However, in such circumstances the MMX routines
; run slightly faster.
;
; The prefetcht0 instructions are commented out in version 2.76:
; they may improve sieving performance on P-III machines such as booth,
; but at the cost of slowing small cases on P-II machines such as portland.
;
; RPB, 20000707, last revised 20000920
;
;	In a typical call kt is about r/64 and the
;	inner loop is executed about kt/2 = r/128 times.
;
	section .text
	global reducer
	align 16

; aptr:DWORD, bptr:DWORD, kt:DWORD, rs:DWORD, prevptr:DWORD
;   36          40         44        48        52

;	Register usage
;
; *a = ebx, *b = esi,
; kt = edi, rs = ecx, temp = ebp,
; new = edx (or eax), old = eax (or edx)

reducer:
	pusha
	mov ebx, [esp+36]	; *a
	mov esi, [esp+40]	; *b
	mov edi, [esp+44]	; j = kt
	mov ecx, [esp+48]	; rs (actually in cl)
	mov eax, [esp+52]	; *prev
	mov edx, [eax]		; new = *prev
	test edi, edi		; check for early exit
	jl .exit		; exit if kt < 0 (as loop kt+1 times)
	test edi, 1		; test low bit of kt
	jnz .init		; jump to main loop if kt odd
				; here j even, do one iteration
	mov eax, edx		; old = new
	mov edx, [ebx+edi*4]	; new = a[j]
	mov ebp, edx		; temp = new
	shrd ebp, eax, cl	; double-word shift of (old,temp) right rs
	xor [esi+edi*4], ebp	; b[j] ^= temp
	dec edi			; j--
	jl .exit		; exit if j le 0

.init:
	mov eax, [ebx+edi*4]	; eax = new = a[j] (old is edx here)
	mov ebp, eax		; temp = new (loop optimisation)

	align 16

;	The following loop is 10 instructions, at least 5 cycles;
;	16 bytes loads, 8 bytes stores (so memory bandwidth is critical).

.loop:				  ; main loop, here j is odd
				  ; edx <-> eax first half

	shrd ebp, edx, cl	  ; double-word shift of (old,temp) right rs
	mov edx, [ebx+edi*4-4] 	  ; edx = new = a[j] (now old is eax)
;;;;;;;	prefetcht0 [ebx+edi*4-36] ; prefetch a one line ahead

	xor [esi+edi*4], ebp  	  ; b[j] ^= temp
;;;;;;;	prefetcht0 [esi+edi*4-32] ; prefetch b one line ahead
	mov ebp, edx		  ; temp = new

	shrd ebp, eax, cl	  ; double-word shift of (old,temp) right rs
	mov eax, [ebx+edi*4-8] 	  ; load eax = new = next a[j]

	xor [esi+edi*4-4], ebp 	  ; b[j-1] ^= temp
	mov ebp, eax		  ; temp = new (for next shrd)

	add edi, byte -2	  ; j -= 2
	jnl .loop		  ; loop if j non-negative

.exit:
	mov eax, [esp+52]	; *prev
	mov [eax], edx		; *prev = new
	popa
	ret

;######################################## reducemr ############################
;
; Version 2.62 of reducemr
;
; typedef unsigned long ULONG;
; void reducemr(ULONG* a, ULONG* b, int kt, int r1, ULONG* prev);
;
; Version of reducer for IBM PC, using MMX instructions.
; Not quite equivalent to reducer because of preloading.
;
; For good performance both a and b should be aligned on 8-byte
; boundaries. If a is not, use reducemx instead.
;
; If data is properly aligned, reducemr should be faster than reducer
; except in the case of very small r (small enough for data to fit in
; the L1 cache).
;
; All "reduce" routines are limited by memory bandwidth if data is
; not in the L2 cache.
;
; Based on gas code for reducem by
; Samuli Larvala (Samuli.Larvala@hut.fi) 20000629
; Converted by Richard Brent 20000706 and 20000816
;
	section .text
	align 16
	global reducemr

reducemr:
; aptr:DWORD, bptr:DWORD, kt:DWORD, r1:DWORD, prevptr:DWORD
;  36          40          44          48	52

	pusha				; save registers

	mov edx, [esp+44]		; kt (loop kt+1 times)
	mov eax, [esp+52]		; address of prev
	movd mm2, [eax]			; old = prev (32 bits)
	mov ecx, [esp+48]		; r1
	test edx, edx			; test kt
	jl   near .exit			; exit if kt < 0

	inc edx                         ; edx = kt+1 (loop kt+1 times)
	mov esi, [esp+36]		; aptr
	mov ebx, [esp+40]		; bptr
	movd mm0, ecx			; mm0 = r1

	xor ecx, byte 63		; We are working with 64-bit words
					; so compute 64-r1
	inc ecx				; The case r1 zero is OK
					; because MMX does shift by 64
					; correctly, i.e. gives zero result !
	movd mm5, ecx			; r1c
	test edx, 1			; test if edx = kt+1 is odd
	jz   .init			; and skip following if not

	movd mm3, [esi+edx*4-4]		; a[j] (32 bits)
	movd mm4, [ebx+edx*4-4]		; b[j] (32 bits)

	psllq mm2, mm5			; old << r1c
	movq mm6, mm3			; new
	psrlq mm3, mm0			; new >> r1

	por mm3, mm2			; (new >> r1) or (old << r1c)
	pxor mm4, mm3			; b[j] xor (new >> r1)
	movq mm2, mm6			; new (becomes old)

	movd [ebx+edx*4-4], mm4		; store new b[j] (32 bits)
	dec  edx
	jz   .exit

.init:
	movq mm1,  [edx*4+esi-8]	; preload a[j] (64 bits)
	movq mm7,  [edx*4+ebx-8]	; preload b[j] (64 bits)

	align 4

.loop:

;       Inner loop of reducemr, 15 instructions, at least 5 cycles;
;	16 bytes loads, 8 bytes stores (so memory bandwidth is critical).

	movq mm3, mm1			; mm3 = a[j]
	movq mm1,  [edx*4+esi-16]	; preload next a[j] (64 bits)
        prefetcht0 [edx*4+esi-48]       ; prefetch a (four ahead)

	psllq mm2, mm5			; old << r1c (shift by 64 is OK)
	movq mm6, mm3			; new
	psrlq mm3, mm0			; new >> r1

	por  mm3, mm2			; (new>>r1) or (old<<r1c)
	movq mm4, mm7			; mm4 = b[j]
	movq mm7,  [edx*4+ebx-16]	; preload next b[j]

        prefetcht0 [edx*4+ebx-48]       ; prefetch b (four ahead)
	pxor mm4, mm3			; b[j] xor ((new>>r1) or (old<<r1c))
	movq mm2, mm6			; new (new becomes old)

	movq [edx*4+ebx-8], mm4		; store b[j]
	add edx, byte -2
	jnz  .loop

.exit:
	mov eax, [esp+52]		; address of prev
	movd [eax], mm2			; return last new in prev (32 bits)
	popa
	emms				; clear MMX state
	ret

;######################################## reducemx ############################
;
; Version 2.70 of reducemx
;
; typedef unsigned long ULONG;
; void reducemx(ULONG* a, ULONG* b, int kt, int r1, ULONG* prev);
;
; This is a modification of reducemr, intended to perform better
; if a is not aligned on an 8-byte boundary (i.e. it is assumed here
; that *a = ....100 in binary).
;
; The caller should ensure that
; there is some zero padding at the top of the array a.
; More precisely, a[kt+1] and a[kt+2] should be zero.
;
; For simplicity, it is assumed that prev is zero on input.
;
; All the "reduce" routines are limited by memory bandwidth if data is
; not in the L2 cache.
;
; Based on gas code for reducem by
; Samuli Larvala (Samuli.Larvala@hut.fi) 20000629
; Converted by Richard Brent 20000706 and 20000816
; Modified from reducemr code to handle the nonaligned case, RPB, 20000913
;
	section .text
	align 16
	global reducemx

reducemx:
; aptr:DWORD, bptr:DWORD, kt:DWORD, r1:DWORD, prevptr:DWORD
;  36          40          44          48	52

	pusha				; save registers

	mov edx, [esp+44]		; kt (should loop kt+1 times)
	pxor mm2, mm2			; assume prev = 0
	mov ecx, [esp+48]		; shift r1, 0 <= r1 < 32
	add ecx, byte 32		; increase shift by 32
	test edx, edx			; test kt
	jl   near .exit			; exit if kt < 0

	add edx, byte 2			; edx = kt+2
	mov esi, [esp+36]		; aptr (assumed not aligned)
	lea esi, [esi-4]		; align it
	mov ebx, [esp+40]		; bptr
	movd mm0, ecx			; mm0 = r1

	xor ecx, byte 63		; We are working with 64-bit words
	inc ecx				; so compute r1c = 64-r1
	movd mm5, ecx			; r1c
	test edx, 1			; test if edx = kt+2 is odd
	jz   .init			; and skip following if not

	movq mm3, [esi+edx*4-4]		; a[j] (64 bits)
	movd mm4, [ebx+edx*4-4]		; b[j] (32 bits)

	psllq mm2, mm5			; old << r1c
	movq mm6, mm3			; new
	psrlq mm3, mm0			; new >> r1

	por mm3, mm2			; (new >> r1) or (old << r1c)
	pxor mm4, mm3			; b[j] xor (new >> r1)
	movq mm2, mm6			; new (becomes old)

	movd [ebx+edx*4-4], mm4		; store new b[j] (32 bits)
	dec  edx
	jz   .exit

.init:
	movq mm1,  [edx*4+esi-8]	; preload a[j] (64 bits)
	movq mm7,  [edx*4+ebx-8]	; preload b[j] (64 bits)

	align 4

.loop:

;       Inner loop of reducemx, 15 instructions, at least 5 cycles;
;	16 bytes loads, 8 bytes stores (so memory bandwidth is critical).

	movq mm3, mm1			; mm3 = a[j]
	movq mm1,  [edx*4+esi-16]	; preload next a[j] (64 bits)
        prefetcht0 [edx*4+esi-48]       ; prefetch a (four ahead)

	psllq mm2, mm5			; old << r1c (shift by 64 is OK)
	movq mm6, mm3			; new
	psrlq mm3, mm0			; new >> r1

	por  mm3, mm2			; (new>>r1) or (old<<r1c)
	movq mm4, mm7			; mm4 = b[j]
	movq mm7,  [edx*4+ebx-16]	; preload next b[j]

        prefetcht0 [edx*4+ebx-48]       ; prefetch b (four ahead)
	pxor mm4, mm3			; b[j] xor ((new>>r1) or (old<<r1c))
	movq mm2, mm6			; new (new becomes old)

	movq [edx*4+ebx-8], mm4		; store b[j]
	add edx, byte -2
	jnz  .loop

.exit:
	mov eax, [esp+52]		; address of prev
	psrlq mm2, 32			; shift return value right
	movd [eax], mm2			; return last new in prev (32 bits)
	popa
	emms				; clear MMX state
	ret
;######################################## interlvf ############################
;
; Version 2.75 of interlvf
;
; void interlvf(unsigned long* a, unsigned long* b, int r);
;
; Version of interlvf for IBM PC, using MMX instructions.
; Loops in forward direction (i.e. loop index goes up)
; which makes a difference to cache performance and extent
; to which b can overlap a.
;
; The inner loop is executed about r/64 times.
;
; Based on gas code for square
; by Samuli Larvala (Samuli.Larvala@hut.fi) 20000629
; and alignmf by Richard Brent 20000816
; Combination of old interlvm with alignmr by RPB 20000906
; Loop optimisation by RPB 20000911
; Version 2.52 moves the 64-bit load earlier as suggested
; by Samuli, implemented RPB 20000911.
; Version 2.53 moves it even earlier.
; Versions 2.54 and 2.60 do some reordering of the loop.
; Version 2.75 has some cosmetic changes.
;
	section .data
	align 16

C0:	dd 0x0F0F0F0F			; These are 64-bit constants
	dd 0x0F0F0F0F			; in two 32-bit pieces
C1:	dd 0x33333333
	dd 0x33333333
D0:	dd 0xAAAAAAAA			; Constants also used in interlvr
	dd 0xAAAAAAAA
D1:	dd 0x55555555
	dd 0x55555555

	section .text
	align 16
	global interlvf

interlvf:
; aptr:DWORD, bptr:DWORD, r:DWORD
;  36          40          44

	pusha				; save registers

	mov  eax, [esp+36]		; *a
	mov  edi, [esp+40]		; *b
	mov  ecx, [esp+44]		; r
	inc  ecx			; r+1
	mov  edx, ecx
	shr  ecx, byte 6		; ecx = q4 = (r+1)/64
	lea  ebx, [4*ecx+eax]		; ebx = *a + q4
	shr  edx, byte 1		; edx = alpha + 1 = (r+1)/2
	and  edx, byte 31		; edx = s1 = (alpha+1) mod 32
	test ecx, ecx
	jl   near .exit			; early exit if q4 negative


;  		Summary of MMX register usage

;	mm0 = C0 = 0F0F0F0F0F0F0F0F	; mm4 = a0 or b0
;	mm1 = C1 = 3333333333333333	; mm5 = a1
;	mm2 = D0 = AAAAAAAAAAAAAAAA	; mm6 = b0 or next b0
;	mm3 = D1 = 5555555555555555	; mm7 = b1 or s1

	movq mm0, [C0]			; Load 64-bit constants
	movq mm1, [C1]
	movq mm2, [D0]
	movq mm3, [D1]

	movd mm4, [eax]			; a0 = first 32 bits of even part
	movq mm6, [ebx]			; b0 = first 64 bits of odd part
 	movd mm7, edx			; mm7 = s1
	inc ecx				; q4+1

;	Following optimisation avoids using a separate loop counter and
;	index register (as in earlier versions) so saves one instruction
;	in the inner loop - this can make a small difference.

	lea eax, [ecx*4+eax]		; Increase pointer registers
	lea ebx, [ecx*4+ebx]		; to compensate for decrease in
	lea edi, [ecx*8+edi]		; loop index which will count
	neg ecx				; up from -(q4+1) to 0

	align 16

.loop:

; 	inner loop of interlvf, 31 instructions, at least 12 cycles,
;	12 bytes loads (only 8 bytes new), 8 bytes stores.
;	Thus memory bandwidth of 8 bytes per 6 cycles should be adequate.

  	movq mm5, mm4			; a1 = a0 =      00000000abcdefgh (hex)
  	psrlq mm4, 4			; a0 = a0 >> 4 = 000000000abcdefg
  	psrlq mm6, mm7			; mm6 = mm6 >> s1

  	punpcklbw mm5, mm4		; a1 =           0aabbccddeeffggh
  	movq mm7, mm6			; b1 = b0 =      xxxxxxxxijklmnop (hex)
  	psrlq mm6, 4			; b0 = b0 >> 4 = 0xxxxxxxxijklmno

					; Following movq loads 8 bytes which
					; may incur a penalty once every eighth
					; iteration (when the eight bytes are
					; in two cache lines).  We have placed
					; the load up as early as possible.

  	pand mm5, mm0			; a1 = a1 & C0 = 0a0b0c0d0e0f0g0h
   	punpcklbw mm7, mm6		; b1 =           xiijjkkllmmnnoop
  	movq mm6, [ecx*4+ebx+4]		; next b0 = 64 bits, odd part (32 new)

  	movq mm4, mm5			; a0 = a1
  	psllq mm5, 2			; a1 = a1 << 2
  	pand mm7, mm0			; b1 = b1 & C0 = 0i0j0k0l0m0n0o0p

  	por  mm5, mm4			; a1 = a1 | a0
  	movq mm4, mm7			; b0 = b1 (use mm4 for b0 here)
  	psllq mm7, 2			; b1 = b1 << 2

					; Following movd only loads 4 bytes
					; so should not involve memory access
					; across a cache line boundary.

   	por  mm7, mm4			; b1 = b1 | b0 (b0 is mm4 here)
   	movd mm4, [ecx*4+eax+4]		; next a0 = 32 bits, even part
  	prefetcht0 [ecx*4+eax+36]	; Prefetch a0 (one line ahead)

  	pand mm7, mm1			; b1 = b1 & C1
  	pand mm5, mm1			; a1 = a1 & C1
  	prefetcht0 [ecx*4+ebx+40]	; Prefetch b0 (one line ahead - note
					; that the movq can cross a cache 
					; line boundary)
  	paddd mm7, mm2			; b1 = b1 + D0
  	paddd mm5, mm2			; a1 = a1 + D0
  	inc  ecx			; increment loop index (anywhere)

  	pand mm7, mm3			; b1 = b1 & D1
  	pand mm5, mm3			; a1 = a1 & D1

  	psllq mm7, 1			; b1 = b1 << 1

  	por  mm5, mm7			; a1 = a1 | b1
 	movd mm7, edx			; mm7 = s1 (for next iteration)

  	movq [ecx*8+edi-8], mm5		; Store 64-bit result a1
  	jnz  .loop			; Jump if ecx nonzero

.exit:
	popa				; restore registers
	emms				; Clear MMX state
	ret

;######################################## interlvr ############################
;
; Version 2.75 of interlvr
;
; void interlvr(unsigned long* a, unsigned long* b, int r);
;
; Version of interlvr for IBM PC, using MMX instructions.
; Similar to interlvf but loops in backward direction
; (i.e. loop index goes down) which makes a difference to cache
; performance and extent to which b can overlap a.
;
; Based on gas code for square
; by Samuli Larvala (Samuli.Larvala@hut.fi) 20000629
; and alignmr by Richard Brent 20000816
; Combination of old interlvm with alignmr by RPB 20000906
; Loop reordering as in interlvf, RPB 20000912
; Version 2.75 has some cosmetic changes.
;
; Note that may access a[-1] due to preloading
;
	section .text
	align 16
	global interlvr

interlvr:
; aptr:DWORD, bptr:DWORD, r:DWORD
;  36          40          44

	pusha				; save registers

	mov  ecx, [esp+44]		; r
	mov  eax, [esp+36]		; *a
	inc  ecx			; r+1
	mov  edi, [esp+40]		; *b
	mov  edx, ecx			; r+1
	shr  ecx, byte 6		; ecx = q4 = (r+1)/64
	lea  ebx, [4*ecx+eax]		; ebx = *a + q4
	shr  edx, byte 1		; edx = alpha + 1 = (r+1)/2
	and  edx, byte 31		; edx = s1 = (alpha+1) mod 32
	test ecx, ecx			; test q4
	jl   near .exit			; early exit if q4 negative

	inc  ecx			; Loop counter q4+1 (counts down)

;  		Summary of MMX register usage

;	mm0 = C0 = 0F0F0F0F0F0F0F0F	; mm4 = a0 or b0
;	mm1 = C1 = 3333333333333333	; mm5 = a1
;	mm2 = D0 = AAAAAAAAAAAAAAAA	; mm6 = b0 or next b0
;	mm3 = D1 = 5555555555555555	; mm7 = b1 or s1

	movq mm0, [C0]			; Load constants
	movq mm1, [C1]			; See interlvf for definitions
	movq mm2, [D0]
	movq mm3, [D1]

	movd mm4, [ecx*4+eax-4]		; a0 = first 32 bits of even part
	movq mm6, [ecx*4+ebx-4]		; b0 = first 64 bits of odd part
	movd mm7, edx			; mm7 = s1

	align 16

.loop:

; 	inner loop of interlvr, 31 instructions, at least 12 cycles;
;	12 bytes loads (only 8 bytes new), 8 bytes stores.

	movq mm5, mm4			; a1 = a0 =      00000000abcdefgh (hex)
 	psrlq mm4, 4			; a0 = a0 >> 4 = 000000000abcdefg
 	psrlq mm6, mm7			; mm6 = mm6 >> s1

 	punpcklbw mm5, mm4		; a1 =           0aabbccddeeffggh
 	movq mm7, mm6			; b1 = b0 =      xxxxxxxxijklmnop (hex)
 	psrlq mm6, 4			; b0 = b0 >> 4 = 0xxxxxxxxijklmno

 	pand mm5, mm0			; a1 = a1 & C0
  	punpcklbw mm7, mm6		; b1 =           xiijjkkllmmnnoop
  	movq mm6, [ecx*4+ebx-8]		; next b0 = 64 bits, odd part (32 new)

  	movq mm4, mm5			; a0 = a1
  	psllq mm5, 2			; a1 = a1 << 2
  	pand mm7, mm0			; b1 = b1 & C0 = 0i0j0k0l0m0n0o0p

  	por  mm5, mm4			; a1 = a1 | a0
  	movq mm4, mm7			; b0 = b1 (use mm4 for b0 here)
  	psllq mm7, 2			; b1 = b1 << 2

  	por  mm7, mm4			; b1 = b1 | b0 (mm4 = b0 here)
   	movd mm4, [ecx*4+eax-8]		; next a0 = 32 bits, even part
  	prefetcht0 [ecx*4+eax-40]	; Prefetch a0 (one line ahead)


  	pand mm7, mm1			; b1 = b1 & C1
  	pand mm5, mm1			; a1 = a1 & C1
  	prefetcht0 [ecx*4+ebx-40]	; Prefetch b0 (one line ahead)

  	paddd mm7, mm2			; b1 = b1 + D0
  	paddd mm5, mm2			; a1 = a1 + D0
  	dec  ecx			; loop counter

  	pand mm7, mm3			; b1 = b1 & D1
  	pand mm5, mm3			; a1 = a1 & D1

  	psllq mm7, 1			; b1 = b1 << 1

  	por  mm5, mm7			; a1 = a1 | b1
	movd mm7, edx			; mm7 = s1 (for next iteration)

  	movq [ecx*8+edi], mm5		; Store 64-bit result a1
  	jnz  .loop			; Jump if ecx nonzero

.exit:
	popa				; restore registers
	emms				; Clear MMX state
	ret

;##############################################################################
